# README for Mira

这是 `tt-ab-analysis-framework` 的 Mira 平台接入版 skill 包。

目录结构应为：
- `SKILL.md`
- `README_for_Mira.md`
- `references/`

建议将本目录作为 Mira 平台注册/挂载的输入目录，并先在小范围灰度验证后再决定是否扩大可见范围。
