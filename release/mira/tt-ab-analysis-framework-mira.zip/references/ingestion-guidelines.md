# Ingestion Guidelines

Use this when turning raw knowledge into reusable glossary or business knowledge.

## Default loop

1. read the raw source
2. organize it into a structured draft
3. print a short `to confirm` list
4. let the user confirm only the unresolved pieces
5. partially ingest confirmed entries into formal storage
6. keep unfinished parts in draft storage

## Rules

- fill only what can be confirmed
- leave uncertain fields blank
- separate metric groups, metrics, dimensions, and business terms
- keep confirmed entries out of the long-term draft area
- prefer Chinese-first confirmation when the user is validating names, meanings, polarity, or priority

## Output expectations

- a structured draft
- a compact `to confirm` list
- a clear split between:
  - confirmed and reusable
  - unresolved and still in review
