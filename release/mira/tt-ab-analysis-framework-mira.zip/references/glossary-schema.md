# Glossary Schema

This document describes how glossary data should be stored and updated.

## Formal storage

Recommended formal storage layers:

- bundled package references:
  - `references/builtin-glossary/`
  - `references/knowledge/`
- repo formal knowledge:
  - `knowledge/glossary/`
  - `knowledge/business_kb.md`

## Dynamic local storage

When a runtime supports local persistence, use:

- `userdata/tt-ab-analysis-framework/`

This is the preferred place for local incremental additions that should persist without requiring a new package release.

## Do not use as primary glossary storage

- chat memory
- finished experiment reports
- one-off temporary task notes

## Lightweight JSON shapes

### metrics_core.json

```json
{
  "groups": [],
  "metrics": []
}
```

### polarity_rules.json

```json
{
  "rules": []
}
```

### business_terms.json

```json
{
  "terms": []
}
```
