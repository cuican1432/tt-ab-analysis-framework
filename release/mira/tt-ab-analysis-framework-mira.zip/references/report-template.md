# Report Template

Use this as the default report shape when the task is to generate an experiment report.

## Suggested order

1. decision summary
2. experiment setup and arm comparison
3. primary evidence
4. major risks and guardrails
5. attribution and business meaning
6. remaining uncertainty
7. next actions

## Section pattern

For each important section, prefer:

1. section judgment
2. representative metrics and values
3. business interpretation
4. attribution chain
5. next step or caveat

## Multi-arm note

If there are multiple treatment arms, include a dedicated comparison section and state:

- which arm is better overall
- which arm is weaker
- why that matters for the decision
