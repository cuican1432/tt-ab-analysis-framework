# Changelog

## 2026-03-31

- packaged `tt-ab-analysis-framework` as a more complete publishable skill bundle
- added package-level `README.md`
- added `ingestion-guidelines.md`
- added `report-template.md`
- added `glossary-schema.md`
- added portable built-in glossary JSON files
- kept the main skill self-contained for Mira-style zip upload
