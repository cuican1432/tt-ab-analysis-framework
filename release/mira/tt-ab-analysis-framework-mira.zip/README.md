# TT AB Analysis Framework Skill Package

This is the publishable skill package for `tt-ab-analysis-framework`.

## What is inside

- `SKILL.md`
  - main runtime instructions
- `CHANGELOG.md`
  - package-level release notes
- `references/core/`
  - framework workflow, rules, runbook, and tooling notes
- `references/knowledge/`
  - markdown-based reusable knowledge references
- `references/builtin-glossary/`
  - lightweight built-in glossary JSON for portable distribution
- `references/ingestion-guidelines.md`
  - how knowledge ingestion and review should work
- `references/report-template.md`
  - the default report-writing skeleton
- `references/glossary-schema.md`
  - storage and update conventions for glossary data

## Package intent

This package is meant to be uploaded as a single skill package in environments such as Mira.

The package should be enough to:

- generate doc-first experiment reports,
- ingest glossary / business knowledge in a structured way,
- and keep a small portable built-in glossary bundled with the skill.

## Storage model

- bundled formal references:
  - `references/builtin-glossary/`
  - `references/knowledge/`
- local dynamic updates:
  - `userdata/tt-ab-analysis-framework/` when the runtime supports local persistence
- memory:
  - useful for helper recall
  - not recommended as the primary team glossary store

## Notes

- Bundled references are good for sharing and versioning.
- Local `userdata` is better for persistent environment-specific additions.
- Finished experiment outputs should not be treated as reusable glossary storage.
